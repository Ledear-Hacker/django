from guardfb import views
from django.conf.urls import url

urlpatterns = [
	url(r'^$', views.home, name='home'),
    url(r'^add/$', views.add, name="add"),
]
