# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.core.mail import send_mail
from django.shortcuts import render
from django.conf import settings

# Create your views here.
def sendanemail(request):
	if request.method == 'POST':
		to = request.POST["toemail"]
		msg = request.POST["msg"]
		send_mail(
			'testing',
			msg,
			settings.EMAIL_HOST_USER,
			[to]






			)
		return render(request, 'email.html')
	else:
		return render(request, 'email.html')			

