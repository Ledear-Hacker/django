from sendemail import views


urlpatterns = [
    url(r'^$', views.home, name='home')
]
